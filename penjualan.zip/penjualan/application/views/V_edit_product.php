<div class="kiri">
	<h2>Input data barang</h2>
	<form method="post">
		<input type="text" name="nama_produk" placeholder="Nama produk" value="<?php echo $edit->nama_produk; ?>">
		<input type="text" name="harga" placeholder="Harga satuan" value="<?php echo $edit->harga_satuan; ?>">
		<input type="text" name="stok" placeholder="Stok" value="<?php echo $edit->stok; ?>">
		<input type="submit" name="simpan" value="Simpan">
	</form>
</div>
<div class="kanan">
	<h2>Tampil data barang</h2>
	<table>
		<tr>
			<td>No</td>
			<td>Nama produk</td>
			<td>Harga satuan</td>
			<td>Stok</td>
			<td>action</td>
		</tr>
		<?php
		if(!empty($produk)){
		 $no=1; foreach($produk as $dproduk): ?>
		<tr>
			<td><?php echo $no; ?></td>
			<td><?php echo $dproduk->nama_produk; ?></td>
			<td>Rp.<?php echo $dproduk->harga_satuan; ?></td>
			<td><?php echo $dproduk->stok ?></td>
			<td> <a href="<?php echo base_url().'C_product/edit/'.$dproduk->id_produk; ?>">Edit</a> | <a href="<?php echo base_url().'C_product/hapus/'.$dproduk->id_produk; ?>"onclick="return confirm('apakah anda yakin ingin menghapus data ini')">hapus</a></td>
		</tr>
		<?php $no++; endforeach; }else{ ?>
			<tr>
				<td colspan="5">Data tidak ditemukan</td>
			</tr>
		<?php } ?>
	</table>
</div>