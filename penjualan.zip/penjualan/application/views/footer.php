 <div style="clear:both"></div>
 &copy; muhammad rifal
    </div>
    </body>
    </html>
