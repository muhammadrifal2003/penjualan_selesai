<?php
class C_beranda extends CI_controller{
	function index(){
		$this->load->view('header');
		$this->load->view('beranda');
		$this->load->view('footer');
	}
}

  ?>